"use client"

import { useState } from "react"
import Image from "next/image"
import { X } from "lucide-react"

const galleryImages: {
  src: string
  alt: string
  title: string
}[] = [
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/13b-ErSB2V5aqzD6X9K6HONsUSex1ixYLW.jpg",
    alt: "Textured floral painting with dark teal background and glowing center",
    title: "Midnight Garden",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Obraz%202.JPG-AD9BglIrMZs6BCSUeG9VaGkhRS9TPF.jpeg",
    alt: "Vibrant textured floral painting with bright yellow-green background",
    title: "Sunlit Meadow",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-10-08%20at%2020.18.59.png-ZO4vsiWLf3VuP4sqYZQCbGIAN7hV2M.jpeg",
    alt: "Soft blue-turquoise textured floral painting with delicate flowers",
    title: "Azure Dreams",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-10-23%20at%2000.04.50.png-M2QeHnhsahRLIw6zebtGLjpqROE8u9.jpeg",
    alt: "Textured floral painting with starry night sky transitioning to meadow",
    title: "Starlit Meadow",
  },
]

export function Gallery() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null)

  return (
    <section id="gallery" className="py-24 bg-gradient-to-b from-background to-muted/20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-light text-foreground mb-4">Gallery</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Explore my textured floral paintings, where each piece is a meditation in color and form
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12 max-w-7xl mx-auto">
          {galleryImages.map((image, index) => (
            <button key={index} onClick={() => setSelectedImage(image.src)} className="group cursor-pointer">
              {/* Frame container with shadow and border */}
              <div className="relative bg-background p-6 rounded-sm shadow-2xl hover:shadow-3xl transition-all duration-300 hover:-translate-y-2">
                {/* Inner frame border */}
                <div className="relative border-2 border-muted/30 p-2">
                  {/* Image container */}
                  <div className="relative aspect-square overflow-hidden">
                    <Image
                      src={image.src || "/placeholder.svg"}
                      alt={image.alt}
                      fill
                      className="object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                  </div>
                </div>
                {/* Artwork title plaque */}
                <div className="mt-4 text-center">
                  <p className="text-sm font-light text-muted-foreground tracking-wide">{image.title}</p>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {selectedImage && (
        <div
          className="fixed inset-0 z-50 bg-background/95 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setSelectedImage(null)}
        >
          <button
            className="absolute top-4 right-4 p-2 rounded-full bg-foreground/10 hover:bg-foreground/20 transition-colors"
            onClick={() => setSelectedImage(null)}
          >
            <X className="h-6 w-6 text-foreground" />
          </button>
          <div className="relative max-w-5xl w-full">
            <div className="bg-background p-8 rounded-sm shadow-2xl">
              <div className="border-2 border-muted/30 p-3">
                <div className="relative w-full aspect-square">
                  <Image
                    src={selectedImage || "/placeholder.svg"}
                    alt="Gallery artwork"
                    fill
                    className="object-contain"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  )
}
