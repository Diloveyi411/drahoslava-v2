import Image from "next/image"

export function About() {
  return (
    <section id="about" className="py-24 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center max-w-6xl mx-auto">
          <div className="relative aspect-[3/4] rounded-2xl overflow-hidden">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Dadi-art-148-6UeSOS1iWq73mQV0lFb7lefRNLNHcz.jpg"
              alt="Drahoslava in her studio with paintbrushes"
              fill
              className="object-cover"
            />
          </div>
          <div className="space-y-6">
            <h2 className="text-4xl md:text-5xl font-light text-foreground">Artist, Psychologist & Vibe-Coder</h2>
            <p className="text-lg text-muted-foreground leading-relaxed">
              I create textured floral paintings that invite you into a world of soft colors and gentle emotions. Each
              piece is a meditation in itself, built layer by layer with intention and care.
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed">
              As a psychologist, I believe in the healing power of creativity. Through painting meditations and 1-on-1
              sessions, I guide people on journeys of self-understanding and self-actualization, where art becomes a
              bridge to inner wisdom.
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed">
              My work spans from textured canvases to comics, each medium offering a unique way to explore emotions,
              stories, and the beautiful complexity of being human.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
