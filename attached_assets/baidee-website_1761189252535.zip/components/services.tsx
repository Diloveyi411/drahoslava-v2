import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Palette, Brain, BookOpen, Users } from "lucide-react"

const services = [
  {
    icon: Palette,
    title: "Painting Meditations",
    description:
      "Join guided painting sessions where creativity meets mindfulness. Experience the therapeutic power of art in a supportive group setting.",
    color: "text-primary",
  },
  {
    icon: Brain,
    title: "1-on-1 Sessions",
    description:
      "Personal sessions combining psychology and art for deep self-understanding and self-actualization. Tailored to your unique journey.",
    color: "text-secondary",
  },
  {
    icon: BookOpen,
    title: "Comics & Illustrations",
    description:
      "Explore stories and emotions through my comic work. Each piece tells a tale of human experience, growth, and connection.",
    color: "text-accent",
  },
  {
    icon: Users,
    title: "Workshops & Events",
    description:
      "Participate in creative workshops and events that blend art, psychology, and community. Learn techniques while exploring your inner world.",
    color: "text-primary",
  },
]

export function Services() {
  return (
    <section id="services" className="py-24 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-light text-foreground mb-4">Services</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Discover ways to connect with your creativity and inner self through art and psychology
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {services.map((service, index) => (
            <Card
              key={index}
              className="border-border/50 bg-card/50 backdrop-blur-sm hover:shadow-lg transition-shadow"
            >
              <CardHeader>
                <div
                  className={`w-12 h-12 rounded-full bg-muted flex items-center justify-center mb-4 ${service.color}`}
                >
                  <service.icon className="h-6 w-6" />
                </div>
                <CardTitle className="text-2xl font-light">{service.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base leading-relaxed">{service.description}</CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
